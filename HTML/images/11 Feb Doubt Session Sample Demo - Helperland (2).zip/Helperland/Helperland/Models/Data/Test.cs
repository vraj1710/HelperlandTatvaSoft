﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Helperland.Models.Data
{
    public partial class Test
    {
        public int TestId { get; set; }
        public string TestName { get; set; }
    }
}
