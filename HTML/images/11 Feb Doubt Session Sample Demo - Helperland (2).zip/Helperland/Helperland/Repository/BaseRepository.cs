﻿using Helperland.Models.Data;

namespace Helperland.Repository
{
    public class BaseRepository
    {
        private HelperlandContext db;

        protected HelperlandContext DBContext
        {
            get
            {
                return db;
            }
        }

        public BaseRepository()
        {
            db = new HelperlandContext();
        }
    }
}