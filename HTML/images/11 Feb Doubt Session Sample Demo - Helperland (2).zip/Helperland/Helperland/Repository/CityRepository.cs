﻿using Helperland.Models.Data;
using Helperland.Models.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace Helperland.Repository
{
    public class StateRepository : BaseRepository
    {
        public List<State> GetAll(out int totalRecords)
        {
            totalRecords = this.DBContext.States.Count();
            return this.DBContext.States.Skip(1).Take(2).ToList();
        }

        [HttpPost]
        public State Add(State state)
        {
            string str = "{\"StateName\":\"test\",\"Id\":15}";
            Newtonsoft.Json.JsonSerializer serializer = new Newtonsoft.Json.JsonSerializer();
            JsonTextReader reader = new JsonTextReader(new StringReader(str));
            State st = serializer.Deserialize<State>(reader);
            this.DBContext.States.Add(state);
            this.DBContext.SaveChanges();
            return state;
        }

        public object serviceRequestLock = new object();
        public bool Accept(int serviceRequestId, Guid oldRecordVersion)
        {
            ServiceRequest req = this.DBContext.ServiceRequests.Where(s => s.ServiceRequestId == serviceRequestId).FirstOrDefault();
            lock (serviceRequestLock)
            { 
                Guid dbRecordVersion = req.RecordVersion.Value;
                if (dbRecordVersion != oldRecordVersion)
                    throw new Exception("The service request in the database is already updated by someone else.");
                req.Status = (int)ServiceRequestStatus.Accepted;
                req.RecordVersion = Guid.NewGuid();
                DBContext.SaveChanges();

            }
            return true;

        }


        enum ServiceRequestStatus
        { 
            Created,
            Paid,
            Accepted,
            Cancelled,
            Completed
        }

        public List<CityModel> GetAllCities()
        {
            var query = from city in DBContext.Cities
                        join state in DBContext.States on city.StateId equals state.Id
                        select new CityModel
                        {
                            CityId = city.Id,
                            CityName = city.CityName,
                            StateName = state.StateName
                        };
            return query.ToList();
        }
    }


}
