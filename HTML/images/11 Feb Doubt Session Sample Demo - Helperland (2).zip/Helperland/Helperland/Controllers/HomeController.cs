﻿using Helperland.Core;
using Helperland.Models;
using Helperland.Models.Data;
using Helperland.Repository;
using log4net;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace Helperland.Controllers
{
    public class HomeController : BaseController
    {
        private readonly ILogger<HomeController> _logger;
        private static readonly ILog log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        public HomeController(ILogger<HomeController> logger)
        {
           
            _logger = logger;
            _logger.LogError("Test Error");
        }

        public IActionResult Index()
        {
            //int totlaRecords = 0;
            StateRepository stateRepo = new StateRepository();
            //var records = stateRepo.GetAll(out totlaRecords);

            //return Json(new BaseList<List<State>>() { Result = records, TotalCount = totlaRecords, Status = "OK" });
            var result = stateRepo.GetAllCities();

            return View(result);
        }

        [HttpPost]
        public ActionResult AddState([FromBody]State state)
        {
            StateRepository stateRepo = new StateRepository();

            var result = stateRepo.Add(state);
            return new JsonResult(result);
        }

        public IActionResult Privacy()
        {
            return View();
        }

        public ActionResult Accept(int serviceRequestId, Guid oldRecordVersion)
        {
            new StateRepository().Accept(serviceRequestId, oldRecordVersion);
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
