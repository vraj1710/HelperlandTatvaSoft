﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace Helperland.Controllers
{
    public class BookServiceRequestController : BaseController
    {
        public IActionResult Index()
        {
            return View();
        }
        [HttpGet]
        public IActionResult GetAddress()
        {
            System.Threading.Thread.Sleep(2000);
            Address address = new Address();
            address.Address1 = "Hedge End";
            return View(address);
        }

        [HttpPost]
        public IActionResult SaveBooking([FromBody] ServiceRequestModel booking)
        {
            if (booking == null)
                return Json(new SingeEntity<ServiceRequestModel>() { Result = null, Status = "ERROR", ErrorMessage = "Error in deserializing submitted data into booking object" }
                    , new System.Text.Json.JsonSerializerOptions()
                    {
                        PropertyNameCaseInsensitive = false
                    });
            else
            {
                var result = new System.Dynamic.ExpandoObject();
                return Json(new SingeEntity<ServiceRequestModel>() { Result = booking, Status = "OK"}
                    , new System.Text.Json.JsonSerializerOptions()
                    {
                        PropertyNameCaseInsensitive = false
                    });
            }
        }


    }
    public class BaseList<T> where T : class
    {
        public int TotalCount { get; set; }
        public T Result { get; set; }
        public string Status { get; set; }
        public string ErrorMessage { get; set; }
    }

    public class SingeEntity<T> where T : class
    {
        public T Result { get; set; }
        public string Status { get; set; }
        public string ErrorMessage { get; set; }
    }
    public class Address
    {
        public string Address1 { get; set; }
    }
    public class ServiceRequestModel
    {
        [JsonPropertyName("zipCode")]
        public string ZipCode { get; set; }
        [JsonPropertyName("address1")]
        public string Address1 { get; set; }
        [JsonPropertyName("hours")]
        public double Hours { get; set; }
        [JsonPropertyName("bookingStartTime")]
        public string BookingStartTime { get; set; }
        public DateTime ServiceStartDate
        {
            get
            {
                DateTime date = DateTime.MinValue;
                if (!string.IsNullOrEmpty(this.BookingStartTime))
                    DateTime.TryParse(this.BookingStartTime, out date);
                return date;
            }
        }
    }
}
