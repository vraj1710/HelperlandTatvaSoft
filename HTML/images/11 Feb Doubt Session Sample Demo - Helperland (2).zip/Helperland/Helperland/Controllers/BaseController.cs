﻿using Helperland.Core;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Helperland.Controllers
{
    public class BaseController : Controller
    {
        public SessionUser LoggedInUser
        {
            get
            {
                //if (HttpContext.Session["LoggedInUser"] == null)
                //    return new SessionUser();
                //return (SessionUser)HttpContext.Session["LoggedInUser"];
                return new SessionUser();
            }
        }

        public IActionResult PrizesAndWarranty()
        {
            return View();
        }

        [HttpGet]
        public IActionResult Login(string userName, string password)
        {
            SessionUser user = new SessionUser();
            user.FirstName = "Get from DB";
            //Add in session
            return View();
        }
    }
}
